require("dotenv").config()


const express = require("express")
const path = require("path")
const cors = require("cors")
const dotenv = require("dotenv")
const mongoose = require("./config/db") // ✅ Připojení k DB přes vlastní soubor
const authRoutes = require("./routes/authRoutes") // ✅ Přihlášení + registrace
const userRoutes = require("./routes/userRoutes") // ✅ Ostatní uživatelské operace


const app = express()
const PORT = process.env.PORT || 3000

console.log("🔍 DEBUG: MONGO_URI =", process.env.MONGO_URI);

app.set("trust proxy", 1)

// Middleware
app.use(express.json())
app.use(cors())
app.use(express.static(path.join(__dirname, "../frontend")))

app.use((req, res, next) => {
    res.setHeader("Content-Type", "application/json");
    console.log(`🔍 [${req.method}] ${req.url}`);
    next();
});


// API Routes
app.use("/api/auth", authRoutes)
app.use("/api/user", userRoutes)

// Testovací GET endpoint
app.get("/", (req, res) => {
    res.sendFile(path.join(__dirname, "../frontend/registration.html"))
})

// Spuštění serveru
app.listen(PORT, () => {
    console.log(`🚀 Server běží na http://localhost:${PORT}`)
})
